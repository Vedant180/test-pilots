package com.syc.finance.v1.bharat.exceptions;

public class RechangeDetailsNotValid extends RuntimeException{

    public RechangeDetailsNotValid(String message){
        super(message);
    }
}
