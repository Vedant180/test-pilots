package com.syc.finance.v1.bharat.exceptions;

public class DetailsNotFountException extends RuntimeException{

    public DetailsNotFountException(String msg){
        super(msg);

    }
}
