package com.syc.finance.v1.bharat.utils;

public class AccountDeletedSuccessResponse {
    public AccountDeletedSuccessResponse(String ex){
        super();
    }
}
