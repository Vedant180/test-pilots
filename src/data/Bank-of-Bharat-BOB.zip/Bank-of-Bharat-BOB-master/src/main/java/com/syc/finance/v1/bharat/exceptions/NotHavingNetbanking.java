package com.syc.finance.v1.bharat.exceptions;

public class NotHavingNetbanking extends RuntimeException{
    public NotHavingNetbanking(String message){
        super(message);
    }
}
